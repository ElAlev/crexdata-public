ODE vs. Discrete:

These are the matlab files accompanying the tutorial at: 

http://MathCancer.org/blog/coarse-graining-discrete-models