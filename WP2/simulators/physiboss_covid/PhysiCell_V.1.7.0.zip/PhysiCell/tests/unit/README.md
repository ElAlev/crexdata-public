# Perform unit tests
```
$ make
$ ./unit_tests 
>>>>>>>>>  Unit tests
...
```
